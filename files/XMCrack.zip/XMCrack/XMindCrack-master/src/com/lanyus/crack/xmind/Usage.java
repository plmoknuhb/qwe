package com.lanyus.crack.xmind;

/**
 * Created by ilanyu on 2016/7/28.
 */
public class Usage {
    public static void main(String[] args) {
        System.out.println("*************************************************************");
        System.out.println("** XMind Crack v1.0                                        **");
        System.out.println("** by: ilanyu                                              **");
        System.out.println("** http://www.lanyus.com/                                  **");
        System.out.println("** Alipay donation: lanyu19950316@gmail.com                **");
        System.out.println("** Please support genuine!!!                               **");
        System.out.println("*************************************************************");
    }
}
